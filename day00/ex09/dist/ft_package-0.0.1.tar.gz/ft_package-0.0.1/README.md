This is a simple example package.

Package pour lapiscine ne sert a rien
