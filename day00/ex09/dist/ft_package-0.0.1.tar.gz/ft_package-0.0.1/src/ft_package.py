def count_in_list(lst: list, value):
    return lst.count(value)
